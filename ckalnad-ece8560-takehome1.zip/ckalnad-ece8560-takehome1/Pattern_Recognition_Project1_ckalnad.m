clearvars;
% THE FIRST CLASSIFICATION CASE STARTS HERE
load train_case_1.dat

% Copy of data into data_matrix
data_matrix = train_case_1;

%Split data into matrices by classes
first_5000_data = data_matrix(1:5000,1:4);
second_5000_data = data_matrix(5001:10000,1:4);
third_5000_data = data_matrix(10001:15000,1:4);

%Define classes
first_5000 = ones(5000,1);
second_5000 = first_5000*2;
third_5000 = first_5000*3;
classes = [first_5000;second_5000;third_5000];
tabulate(classes);

%Scatterplot of 4D data

%Plot 1st 5000
labels = {'1' '2' '3' '4'};
figure(1)
[h,ax] = plotmatrix(first_5000_data);                                       
for i = 1:4                                       
  xlabel(ax(4,i), labels{i})
  ylabel(ax(i,1), labels{i})
end

%Plot 2nd 5000
figure(2)
labels = {'1' '2' '3' '4'};
[h,bx] = plotmatrix(second_5000_data);                      
for i = 1:4                                      
  xlabel(bx(4,i), labels{i})
  ylabel(bx(i,1), labels{i})
end

%Plot 3rd 5000
figure(3)
labels = {'1' '2' '3' '4'};
[h,cx] = plotmatrix(third_5000_data);                       
for i = 1:4                                       
  xlabel(cx(4,i), labels{i})
  ylabel(cx(i,1), labels{i})
end

%Plot all 15000 data points
figure(4)
labels = {'1' '2' '3' '4'};
hold on;
[i,dx] = plotmatrix(data_matrix,'r');
for i = 1:4                                       
  xlabel(dx(4,i), labels{i})
  ylabel(dx(i,1), labels{i})
end

%Calculate covariance and inverse covariance matrices
cov_first_5000 = cov(first_5000_data);
inv_cov_first_5000 = inv(cov_first_5000);

cov_second_5000 = cov(second_5000_data);
inv_cov_second_5000 = inv(cov_second_5000);

cov_third_5000 = cov(third_5000_data);
inv_cov_third_5000 = inv(cov_third_5000);

%Calculate mean
colmean_first_5000 = mean(first_5000_data,1);
colmean_second_5000 = mean(second_5000_data,1);
colmean_third_5000 = mean(third_5000_data,1);

mean_fir_5k = transpose(colmean_first_5000);
mean_sec_5k = transpose(colmean_second_5000);
mean_thr_5k = transpose(colmean_third_5000);

%Shape of pdf contours
w1 = inv_cov_first_5000 * mean_fir_5k;
w2 = inv_cov_second_5000 * mean_sec_5k;
w3 = inv_cov_third_5000 * mean_thr_5k;

wi1 = ((-1/2*((mean_fir_5k')*(mean_fir_5k)))*inv_cov_first_5000);
wi2 = ((-1/2*((mean_sec_5k)')*(mean_sec_5k))*inv_cov_second_5000);
wi3 = ((-1/2*((mean_thr_5k)')*(mean_thr_5k))*inv_cov_third_5000);

%cov_all = cov(trncase1);
%inv_cov = inv(cov_all);

x1 = sym('x1',[1 4]);
x2 = sym('x2',[1 4]);
x3 = sym('x3',[1 4]);

%syms k

%eqn = (transpose(x-mean_fir_5k))*inv_cov*(x-mean_fir_5k) == k
%solk = solve(eqn,[x k])

%determinant functions
g1x = ((w1')*(x1')) - wi1;
sol_g1x = solve(g1x,x1)

g2x = ((w2')*(x2')) - wi2;
sol_g2x = solve(g2x,x2)

g3x = ((w3')*(x3')) - wi3;
sol_g3x = solve(g3x,x3)

%Mixture normalization
cov_matrix = (1/3*(cov_first_5000)) + (1/3*(cov_second_5000)) + (1/3*(cov_third_5000));
inverse_cov_matrix = inv(cov_matrix);

%Hyperplanes
w12 = (inverse_cov_matrix * (mean_fir_5k - mean_sec_5k));
w23 = (inverse_cov_matrix * (mean_sec_5k - mean_thr_5k));
w31 = (inverse_cov_matrix * (mean_thr_5k - mean_fir_5k));
 
%Define aprior probability
class_names = {'1','2','3'};
aprior_prob = [0.33 0.33 0.33];

%Calculate Bayes model
bayes = fitcnb(data_matrix,classes,'ClassNames',class_names,'Prior',aprior_prob)

%Calculate mean and standard deviation of class1
Index_class_w1 = strcmp(bayes.ClassNames,'1');
estimates_w1 = bayes.DistributionParameters{Index_class_w1,1}

%Calculate mean and standard deviation of class2
Index_class_w2 = strcmp(bayes.ClassNames,'2');
estimates_w2 = bayes.DistributionParameters{Index_class_w2,1}

%Calculate mean and standard deviation of class3
Index_class_w3 = strcmp(bayes.ClassNames,'3');
estimates_w3 = bayes.DistributionParameters{Index_class_w3,1}

%Calculate parameters
bayes.DistributionParameters;
prediction_train = resubPredict(bayes);
pred_train = str2double(prediction_train);
ConfusionMat1 = confusionmat(classes,pred_train)

%load test data into test_case1_data
load test_case_1.dat;
test_case1_data = test_case_1;

%Predict the test data classes
prediction_test = predict(bayes,test_case1_data);
[predict,apost,MisClassCost] = predict(bayes,test_case1_data);

%Convert to double to compare classes
pred_test = str2double(prediction_test);

%Count the number of ones in train and test data
ones_train_total = sum(pred_train(:) == 1)
ones_test_total = sum(pred_test(:) == 1)

%Count the number of twos in train and test data
twos_train_total = sum(pred_train(:) == 2)
twos_test_total = sum(pred_test(:) == 2)

%Count the number of threes in train and test data
threes_train_total = sum(pred_train(:) == 3)
threes_test_total = sum(pred_test(:) == 3)

%train_error = (15000 - trace(ConfusionMat1))/15000 
%train_error_class1 = abs(5000 - ones_train_total)
%train_error_class2 = abs(5000 - twos_train_total) 
%train_error_class3 = abs(5000 - threes_test_total)
%train_error1 = 1-((15000 - (train_error_class1 + train_error_class2 + train_error_class3))/15000)

%Calculate percentage of training error
train_error = (15000 - trace(ConfusionMat1))/15000

%Calculate test error
test_error_class1  = abs(5000 - ones_test_total)
test_error_class2  = abs(5000 - twos_test_total)
test_error_class3  = abs(5000 - threes_test_total)

%Calculate percentage of test error
test_error1 = 1-((15000 - (test_error_class1 + test_error_class2 + test_error_class3))/15000)

%Calculate per class percentage of train error
train_error_class1_per  = (abs(5000 - ones_train_total))/5000
train_error_class2_per  = (abs(5000 - twos_train_total))/5000
train_error_class3_per  = (abs(5000 - threes_train_total))/5000

%Calculate per class percentage of test error
test_error_class1_per  = (abs(5000 - ones_test_total))/5000
test_error_class2_per  = (abs(5000 - twos_test_total))/5000
test_error_class3_per  = (abs(5000 - threes_test_total))/5000

%display values of 1st 30 sample data
i=1;
for test_row = 1:30
    aaa = pred_test(test_row,1);
    fprintf("For sample %d class is w%d\n",i,aaa);
    i=i+1;
end

clearvars   %%%%% comment if you want to see case 1 variable values %%%%%
%THE SECOND CLASSIFICATION CASE STARTS HERE
load train_case_2.dat

%copy of data into data_matrix_2
data_matrix_2 = train_case_2;

%Split data into matrices by classes
first_5000_data_2 = data_matrix_2(1:5000,1:4);
second_5000_data_2 = data_matrix_2(5001:10000,1:4);
third_5000_data_2 = data_matrix_2(10001:15000,1:4);

%Define classes
first_5000_2 = ones(5000,1);
second_5000_2 = first_5000_2*2;
third_5000_2 = first_5000_2*3;
classes_2 = [first_5000_2;second_5000_2;third_5000_2];
tabulate(classes_2);

%Scatterplot of 4D data 
%Both training case data are same

%Plot 1st 5000
labels = {'1' '2' '3' '4'};
figure(5)
[h2,ax2] = plotmatrix(first_5000_data_2);                                       
for i = 1:4                                       
  xlabel(ax2(4,i), labels{i})
  ylabel(ax2(i,1), labels{i})
end

%Plot 2nd 5000
figure(6)
labels = {'1' '2' '3' '4'};
[h2,bx2] = plotmatrix(second_5000_data_2);                      
for i = 1:4                                      
  xlabel(bx2(4,i), labels{i})
  ylabel(bx2(i,1), labels{i})
end

%Plot 3rd 5000
figure(7)
labels = {'1' '2' '3' '4'};
[h2,cx2] = plotmatrix(third_5000_data_2);                       
for i = 1:4                                       
  xlabel(cx2(4,i), labels{i})
  ylabel(cx2(i,1), labels{i})
end

%Plot all 15000 data points
figure(8)
labels = {'1' '2' '3' '4'};
hold on;
[i2,dx2] = plotmatrix(data_matrix_2,'r');
for i = 1:4                                       
  xlabel(dx2(4,i), labels{i})
  ylabel(dx2(i,1), labels{i})
end
  
%Calculate covariance and inverse covariance matrices
cov_first_5000_2 = cov(first_5000_data_2);
inv_cov_first_5000_2 = inv(cov_first_5000_2);

cov_second_5000_2 = cov(second_5000_data_2);
inv_cov_second_5000_2 = inv(cov_second_5000_2);

cov_third_5000_2 = cov(third_5000_data_2);
inv_cov_third_5000_2 = inv(cov_third_5000_2);

%Calculate mean
colmean_first_5000_2 = mean(first_5000_data_2,1);
colmean_second_5000_2 = mean(second_5000_data_2,1);
colmean_third_5000_2 = mean(third_5000_data_2,1);

mean_fir_5k_2 = transpose(colmean_first_5000_2);
mean_sec_5k_2 = transpose(colmean_second_5000_2);
mean_thr_5k_2 = transpose(colmean_third_5000_2);

%Shape of pdf contours
w12 = inv_cov_first_5000_2 * mean_fir_5k_2;
w22 = inv_cov_second_5000_2 * mean_sec_5k_2;
w32 = inv_cov_third_5000_2 * mean_thr_5k_2;

wi12 = ((-1/2*((mean_fir_5k_2')*(mean_fir_5k_2)))*inv_cov_first_5000_2);
wi22 = ((-1/2*((mean_sec_5k_2)')*(mean_sec_5k_2))*inv_cov_second_5000_2);
wi32 = ((-1/2*((mean_thr_5k_2)')*(mean_thr_5k_2))*inv_cov_third_5000_2);

x12 = sym('x12',[1 4]);
x22 = sym('x22',[1 4]);
x32 = sym('x32',[1 4]);

%determinant functions
g1x2 = ((w12')*(x12')) - wi12;
sol_g1x2 = solve(g1x2,x12)

g2x2 = ((w22')*(x22')) - wi22;
sol_g2x2 = solve(g2x2,x22)

g3x2 = ((w32')*(x32')) - wi32;
sol_g3x2 = solve(g3x2,x32)

%Mixture normalization
cov_matrix2 = (1/3*(cov_first_5000_2)) + (1/3*(cov_second_5000_2)) + (1/3*(cov_third_5000_2));
inverse_cov_matrix2 = inv(cov_matrix2);

%Hyperplanes
w122 = (inverse_cov_matrix2 * (mean_fir_5k_2 - mean_sec_5k_2));
w232 = (inverse_cov_matrix2 * (mean_sec_5k_2 - mean_thr_5k_2));
w312 = (inverse_cov_matrix2 * (mean_thr_5k_2 - mean_fir_5k_2));

%Define aprior probability
class_names = {'1','2','3'};
aprior_prob_2 = [0.5 0.33 0.166];

%Calculate Bayes model
bayes2 = fitcnb(data_matrix_2,classes_2,'ClassNames',class_names,'Prior',aprior_prob_2)

%Calculate mean and standard deviation of class1
Index_class_w12 = strcmp(bayes2.ClassNames,'1');
estimates_w12 = bayes2.DistributionParameters{Index_class_w12,1}

%Calculate mean and standard deviation of class2
Index_class_w22 = strcmp(bayes2.ClassNames,'2');
estimates_w22 = bayes2.DistributionParameters{Index_class_w22,1}

%Calculate mean and standard deviation of class3
Index_class_w32 = strcmp(bayes2.ClassNames,'3');
estimates_w32 = bayes2.DistributionParameters{Index_class_w32,1}

%Calculate parameters
bayes2.DistributionParameters;
prediction_train_2 = resubPredict(bayes2);
pred_train_2 = str2double(prediction_train_2);
ConfusionMat12 = confusionmat(classes_2,pred_train_2)

%load test data into test_case1_data
load test_case_2.dat;
test_case1_data_2 = test_case_2;

%Predict the test data classes
prediction_test_2 = predict(bayes2,test_case1_data_2);
[predict2,apost2,MisClassCost2] = predict(bayes2,test_case1_data_2);

%Convert to double to compare classes
pred_test_2 = str2double(prediction_test_2);

%Count the number of ones in train and test data
ones_train_total_2 = sum(pred_train_2(:) == 1)
ones_test_total_2 = sum(pred_test_2(:) == 1)

%Count the number of twos in train and test data
twos_train_total_2 = sum(pred_train_2(:) == 2)
twos_test_total_2 = sum(pred_test_2(:) == 2)

%Count the number of threes in train and test data
threes_train_total_2 = sum(pred_train_2(:) == 3)
threes_test_total_2 = sum(pred_test_2(:) == 3)

ones_per = ones_test_total_2/15000
twos_per = twos_test_total_2/15000
threes_per = threes_test_total_2/15000

%train_error = (15000 - trace(ConfusionMat1))/15000 
%train_error_class1 = abs(5000 - ones_train_total)
%train_error_class2 = abs(5000 - twos_train_total) 
%train_error_class3 = abs(5000 - threes_test_total)
%train_error1 = 1-((15000 - (train_error_class1 + train_error_class2 + train_error_class3))/15000)

%Calculate percentage of training error
train_error_2 = (15000 - trace(ConfusionMat12))/15000

%Calculate train error per class
train_error_class1_per_2  = (abs(5000 - ones_train_total_2))/5000
train_error_class2_per_2  = (abs(5000 - twos_train_total_2))/5000
train_error_class3_per_2  = (abs(5000 - threes_train_total_2))/5000

%Calculate test error
test_error_class12  = abs(5000 - ones_test_total_2)
test_error_class22  = abs(5000 - twos_test_total_2)
test_error_class32  = abs(5000 - threes_test_total_2)

%Calculate percentage of test error
test_error1_2 = 1-((15000 - (test_error_class12 + test_error_class22 + test_error_class32))/15000)

%Calculate per class percentage of test error
test_error_class1_per_2  = (abs(5000 - ones_test_total_2))/5000
test_error_class2_per_2  = (abs(5000 - twos_test_total_2))/5000
test_error_class3_per_2  = (abs(5000 - threes_test_total_2))/5000

%Calculate percentage of test error
test_error1_2 = 1-((15000 - (test_error_class12 + test_error_class22 + test_error_class32))/15000)

%Calculate per class percentage of test error
test_error_class1_per_2  = (abs(5000 - ones_test_total_2))/5000
test_error_class2_per_2  = (abs(5000 - twos_test_total_2))/5000
test_error_class3_per_2  = (abs(5000 - threes_test_total_2))/5000

%display values of 1st 30 sample data
i=1;
for test_row_2 = 1:30
    aaa2 = pred_test_2(test_row_2,1);
    fprintf("For sample %d class is w%d\n",i,aaa2);
    i=i+1;
end